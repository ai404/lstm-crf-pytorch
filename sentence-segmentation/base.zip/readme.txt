ah arts and humanities
ls life and medical sciences
ps physical sciences
ss social studies and sciences
lct lecture
sem seminar
